/* 
 * File:   tc.h
 * Author: christian-heimvik
 *
 * Created on October 29, 2024, 7:22 PM
 */

#ifndef TC_H
#define	TC_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TC_H */

